<?php

namespace IWD\OrderManager\Block\Adminhtml\Order\Items\NewItem;

/**
 * Class Simple
 * @package IWD\OrderManager\Block\Adminhtml\Order\Items\NewItem
 */
class Simple extends AbstractType
{

}
