<?php

namespace IWD\OrderManager\Block\Adminhtml\Order\Items;

/**
 * Class Simple
 * @package IWD\OrderManager\Block\Adminhtml\Order\Items
 */
class Simple extends AbstractType
{

}
