<?php

namespace IWD\OrderManager\Block\Adminhtml\Warehouses\Product;

use \Magento\Backend\Block\Widget\Grid\Container;

/**
 * Class Grid
 * @package IWD\OrderManager\Block\Adminhtml\Warehouses\Product
 */
class Grid extends Container
{

}
